package com.example.perappdns

import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.ParcelFileDescriptor
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

enum class VpnState { STOPPED, STARTING, RUNNING }

/**
 * কীভাবে কাজ করে:
 *  - একটা লোকাল VPN তৈরি হয়, কিন্তু শুধু বাছাই করা অ্যাপগুলো এতে ঢোকে (addAllowedApplication)।
 *  - VPN-এর DNS সার্ভার হিসেবে একটা ভার্চুয়াল ঠিকানা (10.111.222.2) দেওয়া হয়
 *    এবং শুধু ওই ঠিকানার রুট TUN-এ আসে। ফলে অ্যাপের বাকি ট্রাফিক স্বাভাবিক পথেই যায়।
 *  - অ্যাপের DNS প্রশ্ন (UDP/53) TUN থেকে পড়ে আসল DNS সার্ভারে পাঠানো হয়, উত্তর আবার TUN-এ ফেরত যায়।
 *  - যে অ্যাপ বাছাই করা হয়নি সেগুলো VPN-এ ঢোকেই না, তাই তাদের DNS আগের মতোই থাকে।
 */
class DnsVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.example.perappdns.START"
        const val ACTION_STOP = "com.example.perappdns.STOP"

        private const val FAKE_DNS = "10.111.222.2"
        private const val VPN_ADDRESS = "10.111.222.1"

        var state by mutableStateOf(VpnState.STOPPED)
        var lastError by mutableStateOf<String?>(null)
        var activeApps by mutableStateOf(0)
    }

    private val generation = AtomicInteger(0)

    @Volatile
    private var currentTun: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP) {
            shutdown()
            stopSelf()
            return START_NOT_STICKY
        }
        val prefs = Prefs(this)
        // সিস্টেম সার্ভিস রিস্টার্ট করলে intent null আসে; তখন শুধু enabled থাকলেই চালু হবে
        if (action == null && !prefs.enabled) {
            stopSelf()
            return START_NOT_STICKY
        }
        start(prefs)
        return START_STICKY
    }

    private fun shutdown() {
        generation.incrementAndGet()
        try {
            currentTun?.close()
        } catch (_: Exception) {
        }
        currentTun = null
        state = VpnState.STOPPED
    }

    private fun start(prefs: Prefs) {
        val myGen = generation.incrementAndGet()
        try {
            currentTun?.close()
        } catch (_: Exception) {
        }
        currentTun = null

        lastError = null
        state = VpnState.STARTING

        val server = prefs.activeServer()
        val apps = prefs.selectedApps
        Thread({ runVpn(myGen, server, apps, prefs) }, "per-app-dns").start()
    }

    private fun resolveServer(host: String): InetAddress {
        if (host.isBlank()) throw IllegalStateException("DNS সার্ভার দেওয়া হয়নি")
        val addrs: Array<InetAddress> = try {
            InetAddress.getAllByName(host)
        } catch (e: Exception) {
            if (host == Prefs.ADGUARD_HOST) {
                arrayOf(InetAddress.getByName(Prefs.ADGUARD_FALLBACK_IP))
            } else {
                throw IllegalStateException("\"$host\" রেজলভ করা যায়নি")
            }
        }
        return addrs.firstOrNull { it is Inet4Address }
            ?: throw IllegalStateException("\"$host\" এর কোনো IPv4 ঠিকানা পাওয়া যায়নি")
    }

    private fun runVpn(myGen: Int, server: String, apps: Set<String>, prefs: Prefs) {
        var tun: ParcelFileDescriptor? = null
        val pool: ExecutorService = Executors.newFixedThreadPool(8)
        try {
            val dnsAddr = resolveServer(server)
            if (generation.get() != myGen) return

            val builder = Builder()
                .setSession("Per-App DNS")
                .setMtu(1500)
                .setBlocking(true)
                .addAddress(VPN_ADDRESS, 24)
                .addDnsServer(FAKE_DNS)
                .addRoute(FAKE_DNS, 32)

            var added = 0
            for (pkg in apps) {
                try {
                    builder.addAllowedApplication(pkg)
                    added++
                } catch (_: PackageManager.NameNotFoundException) {
                    // অ্যাপ আনইনস্টল হয়ে গেছে, বাদ দিন
                }
            }
            if (added == 0) throw IllegalStateException("বাছাই করা কোনো অ্যাপ পাওয়া যায়নি")

            tun = builder.establish()
                ?: throw IllegalStateException("VPN অনুমতি দেওয়া হয়নি")
            if (generation.get() != myGen) return

            currentTun = tun
            activeApps = added
            state = VpnState.RUNNING

            val input = FileInputStream(tun.fileDescriptor)
            val output = FileOutputStream(tun.fileDescriptor)
            val buf = ByteArray(32767)

            while (generation.get() == myGen) {
                val n = input.read(buf)
                if (n <= 0) continue
                handlePacket(buf, n, dnsAddr, output, pool)
            }
        } catch (e: Exception) {
            if (generation.get() == myGen) {
                lastError = e.message ?: e.javaClass.simpleName
                prefs.enabled = false
            }
        } finally {
            pool.shutdownNow()
            try {
                tun?.close()
            } catch (_: Exception) {
            }
            if (generation.get() == myGen) {
                currentTun = null
                state = VpnState.STOPPED
                stopSelf()
            }
        }
    }

    // ---------- প্যাকেট হ্যান্ডলিং ----------

    private fun u16(b: ByteArray, off: Int): Int =
        ((b[off].toInt() and 0xFF) shl 8) or (b[off + 1].toInt() and 0xFF)

    private fun putU16(b: ByteArray, off: Int, v: Int) {
        b[off] = (v shr 8).toByte()
        b[off + 1] = v.toByte()
    }

    private fun fakeDnsBytes(): ByteArray = byteArrayOf(10, 111, 222.toByte(), 2)

    private fun handlePacket(
        p: ByteArray,
        n: Int,
        dnsAddr: InetAddress,
        output: FileOutputStream,
        pool: ExecutorService
    ) {
        if (n < 28) return
        val version = (p[0].toInt() shr 4) and 0xF
        if (version != 4) return
        val ihl = (p[0].toInt() and 0xF) * 4
        if (ihl < 20 || n < ihl + 8) return
        if ((p[9].toInt() and 0xFF) != 17) return // শুধু UDP

        val dstIp = p.copyOfRange(16, 20)
        if (!dstIp.contentEquals(fakeDnsBytes())) return

        val srcPort = u16(p, ihl)
        val dstPort = u16(p, ihl + 2)
        if (dstPort != 53) return

        val udpLen = u16(p, ihl + 4)
        val payloadLen = minOf(udpLen - 8, n - ihl - 8)
        if (payloadLen <= 0) return

        val srcIp = p.copyOfRange(12, 16)
        val payload = p.copyOfRange(ihl + 8, ihl + 8 + payloadLen)

        try {
            pool.execute {
                forwardQuery(payload, srcIp, dstIp, srcPort, dnsAddr, output)
            }
        } catch (_: Exception) {
            // পুল বন্ধ হয়ে গেছে
        }
    }

    private fun forwardQuery(
        payload: ByteArray,
        srcIp: ByteArray,
        dstIp: ByteArray,
        srcPort: Int,
        dnsAddr: InetAddress,
        output: FileOutputStream
    ) {
        try {
            DatagramSocket().use { socket ->
                protect(socket) // এই সকেট যেন VPN-এ আবার না ঢোকে
                socket.soTimeout = 5000
                socket.send(DatagramPacket(payload, payload.size, dnsAddr, 53))
                val respBuf = ByteArray(4096)
                val rp = DatagramPacket(respBuf, respBuf.size)
                socket.receive(rp)

                val packet = buildResponse(respBuf, rp.length, srcIp, dstIp, srcPort)
                synchronized(output) { output.write(packet) }
            }
        } catch (_: Exception) {
            // টাইমআউট/ত্রুটি: অ্যাপ নিজেই আবার চেষ্টা করবে
        }
    }

    private fun buildResponse(
        resp: ByteArray,
        rl: Int,
        clientIp: ByteArray,
        fakeDns: ByteArray,
        clientPort: Int
    ): ByteArray {
        val total = 28 + rl
        val out = ByteArray(total)
        out[0] = 0x45
        putU16(out, 2, total)
        putU16(out, 6, 0x4000) // Don't Fragment
        out[8] = 64
        out[9] = 17
        System.arraycopy(fakeDns, 0, out, 12, 4) // উত্তরের source = ভার্চুয়াল DNS
        System.arraycopy(clientIp, 0, out, 16, 4) // destination = অ্যাপ
        putU16(out, 10, ipChecksum(out, 20))

        putU16(out, 20, 53)
        putU16(out, 22, clientPort)
        putU16(out, 24, 8 + rl)
        putU16(out, 26, 0) // IPv4-এ UDP checksum 0 চলে
        System.arraycopy(resp, 0, out, 28, rl)
        return out
    }

    private fun ipChecksum(b: ByteArray, len: Int): Int {
        var sum = 0
        var i = 0
        while (i < len) {
            sum += ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)
            i += 2
        }
        while ((sum shr 16) != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        return sum.inv() and 0xFFFF
    }

    override fun onRevoke() {
        // ব্যবহারকারী সিস্টেম থেকে VPN বন্ধ করলে
        Prefs(this).enabled = false
        shutdown()
        super.onRevoke()
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }
}
