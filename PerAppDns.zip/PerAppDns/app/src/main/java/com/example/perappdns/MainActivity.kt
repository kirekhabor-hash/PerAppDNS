package com.example.perappdns

import android.app.Application
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

data class AppItem(
    val label: String,
    val pkg: String,
    val icon: ImageBitmap?,
    val launchable: Boolean
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val prefs = Prefs(app)

    var apps by mutableStateOf<List<AppItem>>(emptyList())
        private set
    var loading by mutableStateOf(true)
        private set
    var selected by mutableStateOf(prefs.selectedApps)
        private set
    var useCustom by mutableStateOf(prefs.useCustom)
        private set
    var customServer by mutableStateOf(prefs.customServer)
        private set

    var query by mutableStateOf("")
    var showAll by mutableStateOf(false)

    init {
        loadApps()
    }

    private fun loadApps() {
        viewModelScope.launch(Dispatchers.Default) {
            val ctx = getApplication<Application>()
            val pm = ctx.packageManager
            val list = pm.getInstalledApplications(0)
                .filter { it.packageName != ctx.packageName }
                .map { ai ->
                    val icon = try {
                        ai.loadIcon(pm).toBitmap(96, 96).asImageBitmap()
                    } catch (_: Throwable) {
                        null
                    }
                    AppItem(
                        label = ai.loadLabel(pm).toString(),
                        pkg = ai.packageName,
                        icon = icon,
                        launchable = pm.getLaunchIntentForPackage(ai.packageName) != null
                    )
                }
                .sortedBy { it.label.lowercase() }
            apps = list
            loading = false
        }
    }

    fun toggleApp(pkg: String, on: Boolean) {
        selected = if (on) selected + pkg else selected - pkg
        prefs.selectedApps = selected
    }

    fun setAll(pkgs: List<String>, on: Boolean) {
        selected = if (on) selected + pkgs else selected - pkgs.toSet()
        prefs.selectedApps = selected
    }

    fun changeUseCustom(v: Boolean) {
        useCustom = v
        prefs.useCustom = v
    }

    fun changeCustomServer(v: String) {
        customServer = v
        prefs.customServer = v
    }
}

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()

    private val vpnPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                startVpn()
            } else {
                toast("VPN অনুমতি না দিলে DNS চালু করা যাবে না")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    MainScreen(
                        vm = vm,
                        onToggleMain = { on -> if (on) requestStart() else stopVpn() },
                        onSettingsChanged = { applyChanges() }
                    )
                }
            }
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    /** চালু করার আগে শর্ত যাচাই + VPN অনুমতি */
    private fun requestStart() {
        if (!validate()) return
        val intent = VpnService.prepare(this)
        if (intent != null) vpnPermission.launch(intent) else startVpn()
    }

    private fun validate(): Boolean {
        if (vm.selected.isEmpty()) {
            toast("আগে অন্তত একটা অ্যাপে DNS চালু করুন")
            return false
        }
        if (vm.useCustom && vm.customServer.isBlank()) {
            toast("কাস্টম DNS সার্ভার লিখুন")
            return false
        }
        return true
    }

    private fun startVpn() {
        Prefs(this).enabled = true
        startService(Intent(this, DnsVpnService::class.java).setAction(DnsVpnService.ACTION_START))
    }

    private fun stopVpn() {
        Prefs(this).enabled = false
        startService(Intent(this, DnsVpnService::class.java).setAction(DnsVpnService.ACTION_STOP))
    }

    /** সেটিংস বদলালে সার্ভিস চালু থাকলে নতুন সেটিংসে রিস্টার্ট */
    private fun applyChanges() {
        if (DnsVpnService.state == VpnState.STOPPED) return
        if (vm.selected.isEmpty()) {
            stopVpn()
        } else if (validate()) {
            startVpn()
        }
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun MainScreen(
    vm: MainViewModel,
    onToggleMain: (Boolean) -> Unit,
    onSettingsChanged: () -> Unit
) {
    val state = DnsVpnService.state
    val error = DnsVpnService.lastError

    val filtered = remember(vm.apps, vm.query, vm.showAll) {
        val q = vm.query.trim().lowercase()
        vm.apps.filter { app ->
            (vm.showAll || app.launchable) &&
                (q.isEmpty() || app.label.lowercase().contains(q) || app.pkg.lowercase().contains(q))
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // ---- প্রধান সুইচ ----
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("DNS সার্ভিস", style = MaterialTheme.typography.titleMedium)
                        val statusText = when (state) {
                            VpnState.RUNNING -> "চালু আছে • ${DnsVpnService.activeApps} টি অ্যাপে"
                            VpnState.STARTING -> "চালু হচ্ছে…"
                            VpnState.STOPPED -> "বন্ধ"
                        }
                        Text(statusText, style = MaterialTheme.typography.bodyMedium)
                        if (state == VpnState.STOPPED && error != null) {
                            Text(
                                error,
                                color = MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                    Switch(
                        checked = state != VpnState.STOPPED,
                        onCheckedChange = { onToggleMain(it) }
                    )
                }
            }
        }

        // ---- DNS সার্ভার বাছাই ----
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("DNS সার্ভার", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(4.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                vm.changeUseCustom(false)
                                onSettingsChanged()
                            },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = !vm.useCustom, onClick = {
                            vm.changeUseCustom(false)
                            onSettingsChanged()
                        })
                        Column {
                            Text("ডিফল্ট")
                            Text(
                                Prefs.ADGUARD_HOST,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                vm.changeUseCustom(true)
                                onSettingsChanged()
                            },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = vm.useCustom, onClick = {
                            vm.changeUseCustom(true)
                            onSettingsChanged()
                        })
                        Text("কাস্টম")
                    }

                    if (vm.useCustom) {
                        OutlinedTextField(
                            value = vm.customServer,
                            onValueChange = { vm.changeCustomServer(it) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            label = { Text("DNS সার্ভার (IP বা হোস্টনেম)") },
                            placeholder = { Text("যেমন 1.1.1.1") }
                        )
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = onSettingsChanged) { Text("সংরক্ষণ ও প্রয়োগ") }
                    }

                    Spacer(Modifier.height(8.dp))
                    Text(
                        "সাধারণ DNS (UDP পোর্ট 53) সমর্থিত। DoH/DoT এখানে নেই।",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        // ---- সার্চ ও নিয়ন্ত্রণ ----
        item {
            Column {
                OutlinedTextField(
                    value = vm.query,
                    onValueChange = { vm.query = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("অ্যাপ খুঁজুন") }
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = {
                        vm.setAll(filtered.map { it.pkg }, true)
                        onSettingsChanged()
                    }) { Text("সব চালু") }
                    TextButton(onClick = {
                        vm.setAll(filtered.map { it.pkg }, false)
                        onSettingsChanged()
                    }) { Text("সব বন্ধ") }
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { vm.showAll = !vm.showAll },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Switch(checked = vm.showAll, onCheckedChange = { vm.showAll = it })
                    Spacer(Modifier.size(8.dp))
                    Text("সিস্টেম/লুকানো অ্যাপও দেখান", fontSize = 14.sp)
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    "DNS চালু: ${vm.selected.size} টি অ্যাপে",
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }

        if (vm.loading) {
            item { Text("অ্যাপের তালিকা লোড হচ্ছে…") }
        }

        // ---- অ্যাপ তালিকা ----
        items(filtered, key = { it.pkg }) { app ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (app.icon != null) {
                    Image(
                        bitmap = app.icon,
                        contentDescription = null,
                        modifier = Modifier.size(40.dp)
                    )
                } else {
                    Box(modifier = Modifier.size(40.dp))
                }
                Spacer(Modifier.size(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(app.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        app.pkg,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Switch(
                    checked = app.pkg in vm.selected,
                    onCheckedChange = {
                        vm.toggleApp(app.pkg, it)
                        onSettingsChanged()
                    }
                )
            }
        }
    }
}
