package com.example.perappdns

import android.content.Context

/** সেটিংস সংরক্ষণ: কোন অ্যাপে DNS চালু, কোন DNS সার্ভার, ইত্যাদি। */
class Prefs(context: Context) {
    private val sp = context.applicationContext
        .getSharedPreferences("perapp_dns", Context.MODE_PRIVATE)

    /** true হলে কাস্টম সার্ভার, false হলে ডিফল্ট (AdGuard) */
    var useCustom: Boolean
        get() = sp.getBoolean("use_custom", false)
        set(v) = sp.edit().putBoolean("use_custom", v).apply()

    var customServer: String
        get() = sp.getString("custom_server", "") ?: ""
        set(v) = sp.edit().putString("custom_server", v).apply()

    /** যেসব অ্যাপে DNS চালু রাখা হবে তাদের package name */
    var selectedApps: Set<String>
        get() = sp.getStringSet("apps", emptySet())?.toSet() ?: emptySet()
        set(v) = sp.edit().putStringSet("apps", HashSet(v)).apply()

    /** ব্যবহারকারী সার্ভিস চালু রাখতে চায় কি না */
    var enabled: Boolean
        get() = sp.getBoolean("enabled", false)
        set(v) = sp.edit().putBoolean("enabled", v).apply()

    /** এই মুহূর্তে যে সার্ভারটা ব্যবহার হবে */
    fun activeServer(): String =
        if (useCustom) customServer.trim() else ADGUARD_HOST

    companion object {
        const val ADGUARD_HOST = "dns.adguard.com"

        /** হোস্টনেম রেজলভ না হলে এই IP ব্যবহার হবে (AdGuard DNS) */
        const val ADGUARD_FALLBACK_IP = "94.140.14.14"
    }
}
